package Project.P2.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Contact

{

	String name;
	String number;

	@Id
	String email;
	String message;

	public Contact() {
		super();
	}

	public Contact(String name, String number, String email, String message) {
		super();
		this.name = name;
		
		this.number = number;
		this.email = email;
		this.message = message;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Contact [name=" + name + ", number=" + number + ", email=" + email + ", message=" + message + "]";
	}

}
