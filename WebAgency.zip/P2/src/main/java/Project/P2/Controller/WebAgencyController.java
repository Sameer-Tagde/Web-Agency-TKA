package Project.P2.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import Project.P2.Model.Contact;

@Controller
public class WebAgencyController

{

	@RequestMapping("webagency")
	public String indexPage() {
		return "index";
	}

	@RequestMapping("about")
	public String about() {
		return "about";
	}

	@RequestMapping("do")
	public String Do() {
		return "do";
	}

	@RequestMapping("contact")
	public String contact() {
		return "contact";
	}

	@Autowired
	SessionFactory sf;

	@RequestMapping("contactSave")
	public String contactSave(Contact contact) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(contact);

		tx.commit();

		return "contact";
	}

	@RequestMapping("portfolio")
	public String portfolio() {
		return "portfolio";
	}

}
